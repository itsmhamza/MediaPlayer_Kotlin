package com.example.mediaplayer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.mediaplayer.databinding.ActivitySplashBinding

@SuppressLint("CustomSplashScreen")
class splashActivity : AppCompatActivity() {
    lateinit var binding:ActivitySplashBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)
      //  loadcustomads()
        /*var adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this,"ca-app-pub-3940256099942544/1033173712",adRequest,object:
            InterstitialAdLoadCallback(){
            override fun onAdFailedToLoad(p0: LoadAdError) {
                Log.d("MainActivity", p0?.message)
                mInterstitialAd =null
            }
            override fun onAdLoaded(p0: InterstitialAd) {
                Log.d("MainActivity", "Ad_was loaded.")
                mInterstitialAd= p0
            }
        } )
        mInterstitialAd?.fullScreenContentCallback = object: FullScreenContentCallback(){
            override fun onAdDismissedFullScreenContent() {
                Log.d("MainActivity", "Ad was dismissed.")
                super.onAdDismissedFullScreenContent()
            }

            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                super.onAdFailedToShowFullScreenContent(p0)
                Log.d("MainActivity", "Ad failed to show.")
            }
            override fun onAdShowedFullScreenContent() {
                super.onAdShowedFullScreenContent()
                Log.d("MainActivity", "Ad showed fullscreen content.")
                mInterstitialAd=null
            }
        }
*/
        val pref = this.getSharedPreferences("smartbar", Context.MODE_PRIVATE)
        MainActivity.currenttheme = pref?.getString("theme", "0").toString()
       // setthemeActivity()
       requestRuntimepermission()
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        Handler().postDelayed({
            binding.progres.visibility = View.GONE
            binding.start.visibility =  View.VISIBLE
            binding.text.visibility = View.VISIBLE
        }, 1000)
        binding.start.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
           /* if (mInterstitialAd!=null){
                mInterstitialAd?.show(this)
            }else{
                Log.d("TAG", "The interstitial ad wasn't ready yet.")
            }*/
        }
    }
    private fun requestRuntimepermission():Boolean{
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                10
            )
            return false
        }
        return true
    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),10)
        }
    }
    /*fun loadcustomads(){
        val builder = AdLoader.Builder(this,"ca-app-pub-3940256099942544/2247696110")
            .forNativeAd {
                val adView = LayoutInflater.from(baseContext).inflate(R.layout.nativead,null) as NativeAdView
                if (adView!=null){
                    populateUnifiedNativeAdView(it, adView)
                }
                binding.template.removeAllViews()
                binding.template.addView(adView)
            }
        val videoOptions = VideoOptions.Builder()
            .setStartMuted(true)
            .build()
        val adOptions = NativeAdOptions.Builder()
            .setVideoOptions(videoOptions)
            .build()
        builder.withNativeAdOptions(adOptions)
        val adLoader =builder.withAdListener(object :AdListener(){

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                binding.template.visibility = View.GONE
                binding.templatee.visibility = View.GONE
                binding.templatee.stopShimmer()
            }

            override fun onAdLoaded() {
                super.onAdLoaded()
                binding.templatee.visibility = View.GONE
                binding.templatee.stopShimmer()
            }
        }).build()
        adLoader.loadAd(AdRequest.Builder().build())
    }*/
  /*  private fun populateUnifiedNativeAdView(nativeAd: NativeAd, adView: NativeAdView?) {
        if (adView!=null){
        val mediaView:MediaView=adView.findViewById(R.id.ad_media12)
        adView.mediaView = mediaView
            adView.headlineView = adView.findViewById(R.id.ad_headline)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
            adView.iconView = adView.findViewById(R.id.ad_app_icon)
            adView.starRatingView = adView.findViewById(R.id.ad_rating)
            if (adView.headlineView != null) {
                (adView.headlineView as TextView).text = nativeAd.headline
            }
            if (adView.starRatingView != null) {
                (adView.starRatingView as RatingBar).rating = nativeAd.starRating.toFloat()
            }

            if (adView.callToActionView != null) {
                if (nativeAd.callToAction == null) {
                    adView.callToActionView.visibility = View.INVISIBLE
                } else {
                    adView.callToActionView.visibility = View.VISIBLE
                    (adView.callToActionView as Button).text = nativeAd.callToAction
                }
            }
            if (adView.iconView != null) {
                if (nativeAd.icon == null) {
                    adView.iconView.visibility = View.GONE
                } else {
                    (adView.iconView as ImageView).setImageDrawable(
                        nativeAd.icon.drawable
                    )
                    adView.iconView.visibility = View.VISIBLE
                }
            }
            adView.setNativeAd(nativeAd)
        }
    }*/

    override fun onResume() {
        super.onResume()
    }
}