package com.example.mediaplayer.interfaces

interface onItemRename {

    fun position(position:Int)
    fun delposition(position: Int)
}