package com.example.mediaplayer

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.mediaplayer.Home.Home
import com.example.mediaplayer.R.*
import com.example.mediaplayer.Themes.Themes
import com.example.mediaplayer.databinding.ActivityMainBinding
import com.example.mediaplayer.fragments.Music.*
import com.example.mediaplayer.fragments.Setting
import com.example.mediaplayer.fragments.Video.Video
import com.example.mediaplayer.fragments.Video.VideoRAdopter
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken


class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var adopter:VideoRAdopter

    private var mCountDownTimer: CountDownTimer? = null
    private var mGameIsInProgress = false
    private var mAdIsLoading: Boolean = false
    private var count:Int=0
    private var mTimerMilliseconds = 0L
    private var TAG = "MainActivity"
    companion object
    {
        var currenttheme = String()
        var favtsongs:ArrayList<Musics> = ArrayList()
        var favouritechanged:Boolean=false
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(style.Theme_MediaPlayer)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //retrieve
        val editor = getSharedPreferences("FAVOURITES", MODE_PRIVATE)
        val jsonString = editor.getString("favour",null)
        val typetoken = object : TypeToken<ArrayList<Musics>>(){}.type
        if(jsonString!=null){
            favtsongs.clear()
            val data:ArrayList<Musics> = GsonBuilder().create().fromJson(jsonString,typetoken)
            favtsongs.addAll(data)
        }
        playlists.musicPlaylist=  musicPlaylist()
        val jsonstrringplaylist = editor.getString("musicplaylist",null)
        if(jsonstrringplaylist!=null){
            val dataplaylist:musicPlaylist = GsonBuilder().create().fromJson(jsonstrringplaylist,musicPlaylist::class.java)
            playlists.musicPlaylist =dataplaylist
        }
        val pref = this.getSharedPreferences("smartbar", Context.MODE_PRIVATE)
       // Toast.makeText(this, currenttheme.toInt() , Toast.LENGTH_SHORT).show()
       // loadads()

      //  adopter = VideoRAdopter(this, getAllVideo(this),false,this)
        replaceFragment(Home())
        binding.bottomNavigationView.setSelectedItemId(id.home)
        setSupportActionBar(binding.toolbar)
        currenttheme = pref?.getString("theme", "0").toString()
        setthemeActivity()
        binding.bottomNavigationView.setOnItemSelectedListener {
            when(it.itemId){
                id.home ->
                {
                    replaceFragment(Home())
                    count++
                }
                id.video -> {
                   // replaceFragment1(videos())
                   // currentFragment=videos()
                    replaceFragment(Video())
                    count++
                }
                id.music -> {
                    replaceFragment(Music())
                    count++
                }
                id.themes -> {
                    replaceFragment(Themes())
                    count++
                }
                id.setting  -> {
                    replaceFragment(Setting())
                    count++
                }
            }
            return@setOnItemSelectedListener true
        }
    }
    private fun replaceFragment(fragment: Fragment) {

        val transcation = supportFragmentManager.beginTransaction()
            transcation.replace(id.fragmentContainerView,fragment)
            transcation.disallowAddToBackStack()
            transcation.commit()
    }

    fun setthemeActivity() {
        val currenttheme: String
        val pref = this.getSharedPreferences("smartbar",Context.MODE_PRIVATE)
        currenttheme =pref?.getString("theme","0").toString()
        if (currenttheme.toInt() ==0){
            binding.root.setBackgroundResource(R.color.bg_color)
        }
        else if (currenttheme.toInt() ==1){
            binding.root.setBackgroundResource(R.drawable.bg1)
        }
        else if (currenttheme.toInt() ==2){
            binding.root.setBackgroundResource(R.drawable.bg2)
        }
        else if (currenttheme.toInt() ==3){
            binding.root.setBackgroundResource(R.drawable.bg3)
        }
        else if (currenttheme.toInt() ==4){
            binding.root.setBackgroundResource(R.drawable.bg4)
        }
        else if (currenttheme.toInt() ==5){
            binding.root.setBackgroundResource(R.drawable.bg5)
        }
        else if (currenttheme.toInt() ==6){
            binding.root.setBackgroundResource(R.drawable.bg6)
        }
        else if (currenttheme.toInt() ==7){
            binding.root.setBackgroundResource(R.drawable.bg7)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        return super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.toolbar_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId){
            id.rate ->  {
                val uri =
                Uri.parse("http://play.google.com/store/apps/details?id=\" + this.packageName")
                val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        if(!MusicActivity.isplaying && MusicActivity.musicService!=null){
            exitApplication()
        }
    }
    override fun onResume() {
        super.onResume()
        //for store
        val editor = getSharedPreferences("FAVOURITES", MODE_PRIVATE).edit()
        val jsonString= GsonBuilder().create().toJson(favtsongs)
        editor.putString("favour",jsonString)
        val jsonStringplaylist= GsonBuilder().create().toJson(playlists.musicPlaylist)
        editor.putString("musicplaylist",jsonStringplaylist)
        editor.apply()
    }
    override fun onBackPressed() {
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("VideoPlayer")
            .setMessage("Do you want to Exit?")
            .setPositiveButton("Yes"){
                    self,_->
                finish()
                super.onBackPressed()
            }
            .setNegativeButton("No"){
                    self,_->
                null
            }
            .create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundColor(
            MaterialColors.getColor(this,R.attr.useMaterialThemeColors,
            Color.TRANSPARENT))
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setBackgroundColor(
            MaterialColors.getColor(this,R.attr.useMaterialThemeColors,
            Color.TRANSPARENT))
    }
    /*fun loadcustomads(){
        val builder = AdLoader.Builder(this,"ca-app-pub-3940256099942544/2247696110")
            .forNativeAd {
                val adView = LayoutInflater.from(baseContext).inflate(R.layout.nativead_s,null) as NativeAdView
                if (adView!=null){
                    populateUnifiedNativeAdView(it, adView)
                }
                binding.template.removeAllViews()
                binding.template.addView(adView)
            }
        val videoOptions = VideoOptions.Builder()
            .setStartMuted(true)
            .build()
        val adOptions = NativeAdOptions.Builder()
            .setVideoOptions(videoOptions)
            .build()
        builder.withNativeAdOptions(adOptions)
        val adLoader =builder.withAdListener(object : AdListener(){

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                binding.template.visibility = View.GONE
                binding.templatee.visibility = View.GONE
                binding.templatee.stopShimmer()
            }

            override fun onAdLoaded() {
                super.onAdLoaded()
                binding.templatee.visibility = View.GONE
                binding.templatee.stopShimmer()
            }
        }).build()
        adLoader.loadAd(AdRequest.Builder().build())
    }
    private fun populateUnifiedNativeAdView(nativeAd: NativeAd, adView: NativeAdView?) {
        if (adView!=null){
            adView.headlineView = adView.findViewById(R.id.ad_headline_s)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action_s)
            adView.iconView = adView.findViewById(R.id.ad_app_icon_s)
            adView.starRatingView = adView.findViewById(R.id.ad_rating_s)
            if (adView.headlineView != null) {
                (adView.headlineView as TextView).text = nativeAd.headline
            }
            if (adView.starRatingView != null) {
                (adView.starRatingView as RatingBar).rating = nativeAd.starRating.toFloat()
            }
            if (adView.callToActionView != null) {
                if (nativeAd.callToAction == null) {
                    adView.callToActionView.visibility = View.INVISIBLE
                } else {
                    adView.callToActionView.visibility = View.VISIBLE
                    (adView.callToActionView as Button).text = nativeAd.callToAction
                }
            }
            if (adView.iconView != null) {
                if (nativeAd.icon == null) {
                    adView.iconView.visibility = View.GONE
                } else {
                    (adView.iconView as ImageView).setImageDrawable(
                        nativeAd.icon.drawable
                    )
                    adView.iconView.visibility = View.VISIBLE
                }
            }
            adView.setNativeAd(nativeAd)
        }
    }
    private fun loadAd(){
        var adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            this,"ca-app-pub-3940256099942544/1033173712", adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.d(TAG, adError?.message)
                    mInterstitialAd = null
                    mAdIsLoading = false
                    val error = "domain: ${adError.domain}, code: ${adError.code}, " +
                            "message: ${adError.message}"
                }

                override fun onAdLoaded(p0: InterstitialAd) {
                    super.onAdLoaded(p0)
                    Log.d(TAG, "Ad was loaded.")
                    mInterstitialAd = p0
                    mAdIsLoading = false
                }
                })
    }
    private fun createTimer(milliseconds: Long){
        mCountDownTimer?.cancel()

        mCountDownTimer = object : CountDownTimer(milliseconds, 50) {
            override fun onTick(millisUntilFinished: Long) {
                mTimerMilliseconds = millisUntilFinished
            }

            override fun onFinish() {
                mGameIsInProgress = false

            }
        }
    }
    private fun showInterstitial() {
        if (mInterstitialAd != null) {
            mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Ad was dismissed.")
                    mInterstitialAd = null
                    loadAd()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                    Log.d(TAG, "Ad failed to show.")
                    mInterstitialAd = null
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Ad showed fullscreen content.")
                }
            }
            mInterstitialAd?.show(this)
        } else {
            startGame()
        }
    }
    private fun startGame() {
        if (!mAdIsLoading && mInterstitialAd == null) {
            mAdIsLoading = true
            loadAd()
        }
        resumeGame(300)
    }
    private fun resumeGame(milliseconds: Long) {
        mGameIsInProgress = true
        mTimerMilliseconds = milliseconds
        createTimer(milliseconds)
        mCountDownTimer?.start()
    }*/
  /*  public override fun onPause() {
        mCountDownTimer?.cancel()
        super.onPause()
    }*/


}