package com.example.mediaplayer.fragments.Music

import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mediaplayer.R
import com.example.mediaplayer.databinding.AddPlaylistDialogBinding
import com.example.mediaplayer.databinding.FragmentPlaylistsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class playlists : Fragment() {

    private var _binding: FragmentPlaylistsBinding?=null
    private val binding get() =_binding
    private lateinit var adopter: PlaylistAdopter
    private var mCountDownTimer: CountDownTimer? = null
    private var mGameIsInProgress = false
    private var mAdIsLoading: Boolean = false
    private var mTimerMilliseconds = 0L
    private var TAG = "MainActivity"
    companion object{
        var  musicPlaylist:musicPlaylist = musicPlaylist()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding= FragmentPlaylistsBinding.inflate(inflater,container,false)
        binding?.playlistRecyclerview?.setHasFixedSize(true)
        binding?.playlistRecyclerview?.setItemViewCacheSize(13)
        binding?.playlistRecyclerview?.layoutManager = LinearLayoutManager(this.requireContext())
        adopter = PlaylistAdopter(this.requireContext(),playlistlist = musicPlaylist.ref )
        binding?.playlistRecyclerview?.adapter = adopter
        binding?.addPlaylists?.setOnClickListener {
            customalertialog()
        }
        return binding?.root
    }
    private fun customalertialog(){

        val customDialog = LayoutInflater.from(this.requireContext()).inflate(R.layout.add_playlist_dialog,binding?.root,false)
        val binder = AddPlaylistDialogBinding.bind(customDialog)
        val builder = MaterialAlertDialogBuilder(this.requireContext())
        builder.setView(customDialog)
            .setTitle("Playlist Details")
            .setPositiveButton("Add"){dialog,_->
                val playlistname = binder.playlistName.text
                val createdBy = binder.userPlaylist.text
                if (playlistname!=null && createdBy!=null)
                    if (playlistname.isEmpty() && createdBy.isEmpty())
                    {
                        Toast.makeText(this.requireContext(), "Please Enter Empty fields", Toast.LENGTH_SHORT).show()
                    }
                else{
                        addPlaylist(playlistname.toString(),createdBy.toString())
                    }
                dialog.dismiss()
            }.show()
    }

    private fun addPlaylist(name: String, createdBy: String) {
        var playlistExist = false
        for (i in musicPlaylist.ref)
        {
            if (name.equals(i.name)) {
                playlistExist = true
                break
            }
        }
        if (playlistExist){
            Toast.makeText(this.requireContext(), "Playlist Exist", Toast.LENGTH_SHORT).show()
        }
        else{
            val tempplaylist = playlist()
            tempplaylist.name = name
            tempplaylist.playlist = ArrayList()
            tempplaylist.createdBy = createdBy
            val calender = Calendar.getInstance().time
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
           tempplaylist.createdOn= sdf.format(calender)
            musicPlaylist.ref.add(tempplaylist)
            adopter.refreshPlaylist()
        }
    }
  /*  private fun loadAd(){
        var adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            this.requireContext(),"ca-app-pub-3940256099942544/1033173712", adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.d(TAG, adError?.message)
                    mInterstitialAd = null
                    mAdIsLoading = false
                    val error = "domain: ${adError.domain}, code: ${adError.code}, " +
                            "message: ${adError.message}"
                }

                override fun onAdLoaded(p0: InterstitialAd) {
                    super.onAdLoaded(p0)
                    Log.d(TAG, "Ad was loaded.")
                    mInterstitialAd = p0
                    mAdIsLoading = false
                }
            })
    }
    private fun createTimer(milliseconds: Long){
        mCountDownTimer?.cancel()

        mCountDownTimer = object : CountDownTimer(milliseconds, 50) {
            override fun onTick(millisUntilFinished: Long) {
                mTimerMilliseconds = millisUntilFinished
            }

            override fun onFinish() {
                mGameIsInProgress = false

            }
        }
    }
    private fun showInterstitial() {
        if (mInterstitialAd != null) {
            mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Ad was dismissed.")
                    mInterstitialAd = null
                    loadAd()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                    Log.d(TAG, "Ad failed to show.")
                    mInterstitialAd = null
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Ad showed fullscreen content.")
                }
            }
            mInterstitialAd?.show(this.requireActivity())
        } else {
            startGame()
        }
    }
    private fun startGame() {
        if (!mAdIsLoading && mInterstitialAd == null) {
            mAdIsLoading = true
            loadAd()
        }
        resumeGame(0)
    }
    private fun resumeGame(milliseconds: Long) {
        mGameIsInProgress = true
        mTimerMilliseconds = milliseconds
        createTimer(milliseconds)
        mCountDownTimer?.start()
    }

    override fun onResume() {
        super.onResume()
        if (mGameIsInProgress) {
            resumeGame(mTimerMilliseconds)
        }
        adopter.notifyDataSetChanged()
    }

    override fun onPause() {
        mCountDownTimer?.cancel()
        super.onPause()
    }*/
}