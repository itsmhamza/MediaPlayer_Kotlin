package com.example.mediaplayer.fragments

import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.mediaplayer.PlayerActivity
import com.example.mediaplayer.databinding.FragmentSettingBinding


class Setting : Fragment() {

    private var _binding: FragmentSettingBinding?=null
    private val binding get() =_binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentSettingBinding.inflate(inflater,container,false)
        //save orientation
        val edit = activity?.getSharedPreferences("orientation",Context.MODE_PRIVATE)
            ?.getInt("edit",0)
        if (edit ==1){
            binding?.switchOr?.setChecked(true)
            PlayerActivity.orientationn = true
            binding!!.oritentation.text = "Landscape"
        }
        //save popup
        val edit1 = activity?.getSharedPreferences("popup",Context.MODE_PRIVATE)
            ?.getInt("edit1",0)
        if (edit1 ==1){
            binding?.switchPopup?.setChecked(true)
            PlayerActivity.popup = true
        }
        //save 10s
        val status2 =   activity?.getSharedPreferences("tap",Context.MODE_PRIVATE)?.getBoolean("status2",true)
        binding?.switchDouble?.setChecked(status2!!)
       /* val edit2 = activity?.getSharedPreferences("doubletap",Context.MODE_PRIVATE)
            ?.getInt("edit2",0)
        if (edit2 ==1){
            binding?.switchDouble?.setChecked(true)
            PlayerActivity.doubletap = true
        }*/
        //save gesture
        val edit3 = activity?.getSharedPreferences("gesture",Context.MODE_PRIVATE)
            ?.getInt("edit3",0)
        if (edit3 ==1) {
            binding?.switchgesture?.setChecked(true)
            PlayerActivity.gesture = true
        }
            //save media name
        val status =   activity?.getSharedPreferences("media",Context.MODE_PRIVATE)?.getBoolean("status",true)
        binding?.switchmedia?.setChecked(status!!)
           /* val edit4 = activity?.getSharedPreferences("media", Context.MODE_PRIVATE)
                ?.getInt("edit4", 0)
            if (edit4 == 1) {
                binding?.switchmedia?.setChecked(true)
                VideoRAdopter.media = true
                VideoRAdopterg.media = true
            }*/
            binding?.privacy?.setOnClickListener {
                val uri =
                    Uri.parse("https://climaxtechnologyapps.blogspot.com/2021/09/privacy-policy-of-climax-technology-apps.html")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                startActivity(intent)
            }
            binding?.materialCardView?.setOnClickListener {
                val uri =
                    Uri.parse("http://play.google.com/store/apps/details?id=\" + this.packageName")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                startActivity(intent)
            }
            binding?.switchOr?.setOnCheckedChangeListener { buttonView, isChecked ->
                if (isChecked) {
                    activity?.getSharedPreferences("orientation", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit", 1)?.apply()
                    PlayerActivity.orientationn = true
                    binding!!.oritentation.text = "Landscape"
                } else {
                    activity?.getSharedPreferences("orientation", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit", 0)?.apply()
                    PlayerActivity.orientationn = false
                    binding!!.oritentation.text = "Potrait"

                }
            }
            binding?.switchPopup?.setOnCheckedChangeListener { buttonView, isChecked ->
                if (isChecked) {
                    activity?.getSharedPreferences("popup", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit1", 1)?.apply()
                    PlayerActivity.popup = true
                } else {
                    activity?.getSharedPreferences("popup", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit1", 0)?.apply()
                    PlayerActivity.popup = false
                }
            }
            binding?.switchDouble?.setOnCheckedChangeListener { buttonView, isChecked ->
                activity?.getSharedPreferences("tap",Context.MODE_PRIVATE)?.edit()
                    ?.putBoolean("status2",isChecked)?.apply()
                Log.e(TAG, "$isChecked" )
          /*      if (isChecked) {
                    activity?.getSharedPreferences("doubletap", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit2", 1)?.apply()
                    PlayerActivity.doubletap = true
                } else {
                    activity?.getSharedPreferences("doubletap", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit2", 0)?.apply()
                    PlayerActivity.doubletap = false
                }*/
            }
            binding?.switchgesture?.setOnCheckedChangeListener { buttonView, isChecked ->
                if (isChecked) {
                    activity?.getSharedPreferences("gesture", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit3", 1)?.apply()
                    PlayerActivity.gesture = true
                } else {
                    activity?.getSharedPreferences("gesture", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit3", 0)?.apply()
                    PlayerActivity.gesture = false
                }
            }
            binding?.switchmedia?.setOnCheckedChangeListener { buttonView, isChecked ->
                activity?.getSharedPreferences("media",Context.MODE_PRIVATE)?.edit()
                    ?.putBoolean("status",isChecked)?.apply()
                Log.e(TAG, "$isChecked" )
              /*  if (isChecked) {
                    activity?.getSharedPreferences("media", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit4", 1)?.apply()
                    VideoRAdopter.media = true
                    VideoRAdopterg.media = true

                } else {
                    activity?.getSharedPreferences("media", Context.MODE_PRIVATE)?.edit()
                        ?.putInt("edit4", 0)?.apply()
                    VideoRAdopter.media = false
                    VideoRAdopterg.media = false
                }*/
            }
        return binding?.root
    }
}